# activity-planning-app

The app allows the following:
- management of a task list. Activity: title, description, type, duration
- add, delete, modify, and display activities
- activity search
- filter activities by: description, type
- sort activities by: title, description, type + duration
- undo activity

The graphical interface was created using qt and the data was saved in txt and CSV files
