#include "lab10_11.h"

lab10_11::lab10_11(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
